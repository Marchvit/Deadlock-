//! Отправка матчей в deadlock-api прямо из приложения.
//!
//! Повторяет пассивную часть официального инструмента deadlock-api-ingest (MIT,
//! github.com/deadlock-api/deadlock-api-ingest): когда Deadlock показывает матч, Steam скачивает
//! файл `replayNNN.valve.net/1422450/<match_id>_<salt>.meta.bz2` и кладёт его в свой кэш
//! `Steam/appcache/httpcache`. В начале такого файла записан его адрес. Мы читаем только первые
//! 200 байт файлов кэша, достаём номер матча и «соль» (ключ, по которому deadlock-api сможет
//! скачать матч) и отправляем их на `POST /v1/matches/salts`.
//!
//! Что не делаем: не входим в Steam, не читаем сохранённую сессию Steam, не меняем файлы.
//! Сеть здесь не используется: отправку делает интерфейс (см. `dist/index.html`).

use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::fs::{File, OpenOptions};
use std::io::{BufRead, BufReader, Read, Write};
use std::path::{Path, PathBuf};
use std::time::SystemTime;

const DEADLOCK_APP_ID: &str = "1422450";
const MAX_BYTES_TO_READ: usize = 200;
const HOST_SUFFIX: &[u8] = b".valve.net";
/// Самые большие известные номера матчей далеко меньше; так же отсекает сервер.
const MAX_MATCH_ID: u64 = 10_000_000_000;

/// Номер матча и соли из адреса файла в кэше Steam.
#[derive(Serialize, Deserialize, Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Salt {
    pub match_id: u64,
    pub cluster_id: Option<u32>,
    pub metadata_salt: Option<u32>,
    pub replay_salt: Option<u32>,
}

impl Salt {
    /// Ключ для «уже отправляли»: у матча бывают отдельно соль метаданных и соль записи.
    pub fn key(&self) -> (u64, bool) {
        (self.match_id, self.metadata_salt.is_some())
    }

    /// `http://replay183.valve.net/1422450/42476710_428480166.meta.bz2[?v=2]`
    pub fn from_url(url: &str) -> Option<Self> {
        let base = url.split_once('?').map_or(url, |(p, _)| p);
        let (cluster, rest) = base
            .strip_prefix("http://replay")?
            .split_once(".valve.net/")?;
        let (app, name) = rest.rsplit_once('/')?;
        if app != DEADLOCK_APP_ID {
            return None;
        }
        let (stem, meta) = if let Some(s) = name.strip_suffix(".meta.bz2") {
            (s, true)
        } else if let Some(s) = name.strip_suffix(".dem.bz2") {
            (s, false)
        } else {
            return None;
        };
        let (m, salt) = stem.split_once('_')?;
        let match_id: u64 = m.parse().ok()?;
        let salt: u32 = salt.parse().ok()?;
        if match_id == 0 || match_id > MAX_MATCH_ID {
            return None;
        }
        Some(Self {
            match_id,
            cluster_id: Some(cluster.parse().ok()?),
            metadata_salt: meta.then_some(salt),
            replay_salt: (!meta).then_some(salt),
        })
    }
}

fn find(hay: &[u8], needle: &[u8], from: usize) -> Option<usize> {
    if needle.is_empty() || hay.len() < needle.len() {
        return None;
    }
    (from..=hay.len() - needle.len()).find(|&i| &hay[i..i + needle.len()] == needle)
}

/// Ищет адрес `http://replay….valve.net/…1422450…` в начале файла кэша.
pub fn extract_replay_url(data: &[u8]) -> Option<String> {
    let mut from = 0;
    while let Some(i) = find(data, HOST_SUFFIX, from) {
        from = i + 1;
        let host_start = (0..i)
            .rev()
            .find(|&p| !data[p].is_ascii_alphanumeric() && data[p] != b'.')
            .map_or(0, |p| p + 1);
        let host_end = i + HOST_SUFFIX.len();
        let Ok(host) = std::str::from_utf8(&data[host_start..host_end]) else {
            continue;
        };
        if !host.starts_with("replay") {
            continue;
        }
        let Some(slash) = data[host_end..].iter().position(|&b| b == b'/') else {
            continue;
        };
        let path = &data[host_end + slash..];
        let end = path
            .iter()
            .position(|b| matches!(b, b' ' | b'\'' | 0 | b'\n' | b'\r' | b'"'))
            .unwrap_or(path.len());
        let Ok(path) = std::str::from_utf8(&path[..end]) else {
            continue;
        };
        if path.contains(DEADLOCK_APP_ID) {
            return Some(format!("http://{host}{path}"));
        }
    }
    None
}

fn salt_from_file(path: &Path) -> Option<Salt> {
    let mut buf = [0u8; MAX_BYTES_TO_READ];
    let n = File::open(path).ok()?.read(&mut buf).ok()?;
    Salt::from_url(&extract_replay_url(&buf[..n])?)
}

/// Обходит папку кэша. Если задан `newer_than`, читает только файлы, изменённые позже:
/// повторные проверки стоят лишь чтения метаданных файлов, а не их содержимого.
pub fn scan(dir: &Path, newer_than: Option<SystemTime>, out: &mut Vec<Salt>) {
    let Ok(entries) = std::fs::read_dir(dir) else {
        return;
    };
    for e in entries.flatten() {
        let Ok(ft) = e.file_type() else { continue };
        let path = e.path();
        if ft.is_dir() {
            scan(&path, newer_than, out);
        } else if ft.is_file() {
            if let Some(t) = newer_than {
                let fresh = e
                    .metadata()
                    .and_then(|m| m.modified())
                    .map_or(true, |m| m > t);
                if !fresh {
                    continue;
                }
            }
            if let Some(s) = salt_from_file(&path) {
                out.push(s);
            }
        }
    }
}

/// Папки `appcache/httpcache` во всех найденных установках Steam.
pub fn cache_dirs(steam_roots: &[PathBuf]) -> Vec<PathBuf> {
    let mut seen = HashSet::new();
    steam_roots
        .iter()
        .map(|r| r.join("appcache").join("httpcache"))
        .filter(|d| d.is_dir())
        .filter(|d| seen.insert(std::fs::canonicalize(d).unwrap_or_else(|_| d.clone())))
        .collect()
}

/// Account ID (SteamID3) пользователя, который сейчас вошёл в Steam: `config/loginusers.vdf`,
/// запись с `"MostRecent" "1"`. Это публичный номер, он виден в каждом матче.
pub fn parse_login_users(vdf: &str) -> Option<u32> {
    const STEAM_ID64_BASE: u64 = 76_561_197_960_265_728;
    let mut current: Option<u64> = None;
    let mut fallback: Option<u64> = None;
    for line in vdf.lines() {
        let q: Vec<&str> = line.split('"').skip(1).step_by(2).collect();
        match q.as_slice() {
            [id] if id.len() == 17 && id.bytes().all(|b| b.is_ascii_digit()) => {
                current = id.parse().ok();
                fallback = fallback.or(current);
            }
            [k, v] if k.eq_ignore_ascii_case("MostRecent") && *v == "1" => {
                if let Some(id) = current {
                    return u32::try_from(id.checked_sub(STEAM_ID64_BASE)?).ok();
                }
            }
            _ => {}
        }
    }
    u32::try_from(fallback?.checked_sub(STEAM_ID64_BASE)?).ok()
}

pub fn steam_account(steam_roots: &[PathBuf]) -> Option<u32> {
    steam_roots.iter().find_map(|r| {
        let text = std::fs::read_to_string(r.join("config").join("loginusers.vdf")).ok()?;
        parse_login_users(&text)
    })
}

/// Что уже отправлено (переживает перезапуск): строки `match_id m|r`.
pub struct SentLog {
    path: Option<PathBuf>,
    set: HashSet<(u64, bool)>,
}

impl SentLog {
    pub fn open(path: Option<PathBuf>) -> Self {
        let mut set = HashSet::new();
        if let Some(f) = path.as_ref().and_then(|p| File::open(p).ok()) {
            for line in BufReader::new(f).lines().map_while(Result::ok) {
                if let Some((id, kind)) = line.trim().split_once(' ') {
                    if let Ok(id) = id.parse() {
                        set.insert((id, kind == "m"));
                    }
                }
            }
        }
        Self { path, set }
    }

    pub fn contains(&self, s: &Salt) -> bool {
        self.set.contains(&s.key())
    }

    pub fn len(&self) -> usize {
        self.set.len()
    }

    pub fn add(&mut self, salts: &[Salt]) {
        let new: Vec<&Salt> = salts.iter().filter(|s| self.set.insert(s.key())).collect();
        if new.is_empty() {
            return;
        }
        let Some(p) = &self.path else { return };
        if let Some(dir) = p.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        if let Ok(mut f) = OpenOptions::new().create(true).append(true).open(p) {
            let text: String = new
                .iter()
                .map(|s| {
                    format!(
                        "{} {}\n",
                        s.match_id,
                        if s.metadata_salt.is_some() { "m" } else { "r" }
                    )
                })
                .collect();
            let _ = f.write_all(text.as_bytes());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn salts_from_urls() {
        let s = Salt::from_url("http://replay404.valve.net/1422450/37959196_937530290.meta.bz2")
            .unwrap();
        assert_eq!(
            (s.cluster_id, s.match_id, s.metadata_salt, s.replay_salt),
            (Some(404), 37959196, Some(937530290), None)
        );
        let s = Salt::from_url("http://replay183.valve.net/1422450/42476710_428480166.dem.bz2?v=2")
            .unwrap();
        assert_eq!(
            (s.cluster_id, s.match_id, s.metadata_salt, s.replay_salt),
            (Some(183), 42476710, None, Some(428480166))
        );
        // Другая игра, мусор и слишком большой номер не проходят
        assert!(
            Salt::from_url("http://replay183.valve.net/570/42476710_428480166.dem.bz2").is_none()
        );
        assert!(Salt::from_url("http://replay183.valve.net/1422450/abc_1.meta.bz2").is_none());
        assert!(
            Salt::from_url("http://replay1.valve.net/1422450/99999999999_1.meta.bz2").is_none()
        );
        assert!(Salt::from_url("https://cdn.steamstatic.com/1422450/1_2.meta.bz2").is_none());
    }

    #[test]
    fn url_inside_cache_file_header() {
        let mut f = b"\x00\x01KEY:http://replay404.valve.net/1422450/37959196_937530290.meta.bz2\x00garbage".to_vec();
        f.resize(300, 0);
        assert_eq!(
            extract_replay_url(&f[..200]).as_deref(),
            Some("http://replay404.valve.net/1422450/37959196_937530290.meta.bz2")
        );
        assert!(extract_replay_url(b"GET http://cdn.valve.net/other/1.png HTTP/1.1").is_none());
        assert!(extract_replay_url(b"http://replay1.valve.net/570/5_6.meta.bz2\n").is_none());
    }

    #[test]
    fn login_users_most_recent() {
        let vdf = "\"users\"\n{\n\t\"76561198000000001\"\n\t{\n\t\t\"AccountName\"\t\t\"a\"\n\t\t\"MostRecent\"\t\t\"0\"\n\t}\n\t\"76561198141439975\"\n\t{\n\t\t\"AccountName\"\t\t\"b\"\n\t\t\"MostRecent\"\t\t\"1\"\n\t}\n}\n";
        assert_eq!(parse_login_users(vdf), Some(181174247));
        // Без MostRecent берём первого
        assert_eq!(
            parse_login_users("\"users\"\n{\n\"76561198000000001\"\n{\n}\n}"),
            Some(39734273)
        );
        assert_eq!(parse_login_users("мусор"), None);
    }

    #[test]
    fn scan_and_sent_log() {
        let root = std::env::temp_dir().join(format!("dc-ingest-test-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        let cache = root.join("Steam/appcache/httpcache/3f");
        std::fs::create_dir_all(&cache).unwrap();
        std::fs::write(
            cache.join("a1"),
            b"http://replay7.valve.net/1422450/111_222.meta.bz2\x00",
        )
        .unwrap();
        std::fs::write(
            cache.join("a2"),
            b"http://replay7.valve.net/1422450/111_333.dem.bz2\x00",
        )
        .unwrap();
        std::fs::write(cache.join("a3"), b"\x89PNG not a replay").unwrap();
        let dirs = cache_dirs(&[root.join("Steam"), root.join("Steam")]);
        assert_eq!(dirs.len(), 1);
        let mut out = Vec::new();
        scan(&dirs[0], None, &mut out);
        out.sort_by_key(|s| s.metadata_salt.is_none());
        assert_eq!(out.len(), 2);
        assert_eq!(out[0].metadata_salt, Some(222));
        // Повторная проверка видит только новые файлы
        let mut again = Vec::new();
        scan(
            &dirs[0],
            Some(SystemTime::now() + std::time::Duration::from_secs(5)),
            &mut again,
        );
        assert!(again.is_empty());

        let log = root.join("data/sent.txt");
        let mut sent = SentLog::open(Some(log.clone()));
        sent.add(&out);
        sent.add(&out);
        assert_eq!(sent.len(), 2);
        let reopened = SentLog::open(Some(log));
        assert!(reopened.contains(&out[0]) && reopened.contains(&out[1]));
        let _ = std::fs::remove_dir_all(&root);
    }
}
